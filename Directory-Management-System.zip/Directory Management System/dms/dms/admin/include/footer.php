 <footer class="sticky-footer">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright © <a href="https://itsourcecode.com" target="_blank">Itsourcecode.com</a></span>
          </div>
        </div>
      </footer>